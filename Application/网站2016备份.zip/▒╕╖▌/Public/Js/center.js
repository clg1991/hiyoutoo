

$(document).ready(function(){
 

      $(".avatar-module").hover(
      function(){
       $(".avatar-module").children("a").show();
            },


      function(){
      $(".avatar-module").children("a").hide();
});
	 
});