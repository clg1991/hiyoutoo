<?php
return array(

'__PUBLIC__' => "AA/Application/Public",  
	//'配置项'=>'配置值'
);