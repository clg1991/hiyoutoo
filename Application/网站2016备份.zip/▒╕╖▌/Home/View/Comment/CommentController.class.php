<?php
namespace Home\Controller;
use Think\Controller;
class CommentController extends Controller{
	
	public function commentshow(){	
          $this->display();
}

	
		

 }
 
?>